from flask import Flask, render_template, request, jsonify
from transformers import pipeline
import os
from pathlib import Path

app = Flask(__name__)
REPO_ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = os.environ.get('MODEL_DIR', str(REPO_ROOT / 'outputs' / 'ner-model'))

# Color mapping for entity types
ENTITY_COLORS = {
    'EMAIL': '#FF6B6B',
    'URL': '#4ECDC4',
    'UID': '#45B7D1',
    'PHONE': '#FFA07A',
    'NAME': '#98D8C8',
    'ADDRESS': '#F7DC6F',
    'DATE': '#BB8FCE',
    'CREDIT_CARD': '#F8B88B',
    'SSN': '#85C1E2',
    'O': '#D3D3D3'  
}

print(f"Loading model from: {MODEL_DIR}")
try:
    nlp = pipeline('token-classification', model=MODEL_DIR, tokenizer=MODEL_DIR, aggregation_strategy='simple')
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error: Failed to load model from {MODEL_DIR}")
    print(f"Details: {e}")
    print("Please ensure the model directory exists and contains valid model files.")
    raise

@app.route('/')
def index():
    return render_template('index.html')

def process_text_with_highlights(text):
    """Process text and return HTML with color-coded entity highlights"""
    preds = nlp(text)
    
    # Build entity map with colors
    entity_spans = []
    for p in preds:
        entity_type = p.get('entity_group', 'O')
        if entity_type != 'O' and p.get('score', 0) > 0.4:
            color = ENTITY_COLORS.get(entity_type, '#FFFF00')
            entity_spans.append({
                'start': p['start'],
                'end': p['end'],
                'type': entity_type,
                'color': color,
                'score': float(p.get('score', 0))
            })
    
    # Sort by start position
    entity_spans.sort(key=lambda x: x['start'])
    
    # Build highlighted HTML
    html_content = ''
    last_end = 0
    
    for span in entity_spans:
        html_content += text[last_end:span['start']]
        html_content += f'<span class="highlight" style="background-color: {span["color"]}; color: white; padding: 2px 4px; border-radius: 3px; font-weight: bold;" title="{span["type"]} ({span["score"]:.2%})">{text[span["start"]:span["end"]]}</span>'
        last_end = span['end']
    
    html_content += text[last_end:]
    
    return html_content, entity_spans, preds

@app.route('/mask', methods=['POST'])
def mask():
    text = request.form.get('text', '')
    
    html_output, entity_spans, preds = process_text_with_highlights(text)
    
    # Create masked version
    masked = text
    for span in reversed(entity_spans):
        masked = masked[:span['start']] + '[MASK]' + masked[span['end']:]
    
    preds_serializable = []
    for p in preds:
        p_dict = dict(p)
        if 'score' in p_dict and hasattr(p_dict['score'], 'item'):
            p_dict['score'] = float(p_dict['score'].item())
        elif 'score' in p_dict:
            p_dict['score'] = float(p_dict['score'])
        preds_serializable.append(p_dict)
    
    return jsonify({
        'masked': masked,
        'highlighted': html_output,
        'entities': entity_spans,
        'predictions': preds_serializable
    })

@app.route('/batch-upload', methods=['POST'])
def batch_upload():
    """Handle batch file upload and processing"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not file.filename.endswith('.txt'):
        return jsonify({'error': 'Only .txt files are supported'}), 400
    
    try:
        content = file.read().decode('utf-8')
        lines = content.strip().split('\n')
        
        results = []
        for idx, line in enumerate(lines, 1):
            if line.strip():
                html_output, entity_spans, preds = process_text_with_highlights(line)
                
                masked = line
                for span in reversed(entity_spans):
                    masked = masked[:span['start']] + '[MASK]' + masked[span['end']:]
                
                results.append({
                    'line_number': idx,
                    'original': line,
                    'masked': masked,
                    'highlighted': html_output,
                    'entities_found': len(entity_spans),
                    'entities': entity_spans
                })
        
        return jsonify({
            'success': True,
            'total_lines': len(lines),
            'processed_lines': len(results),
            'results': results
        })
    
    except Exception as e:
        return jsonify({'error': f'Error processing file: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)