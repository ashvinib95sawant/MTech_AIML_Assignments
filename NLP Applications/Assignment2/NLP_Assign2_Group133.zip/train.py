import ast
import os
from pathlib import Path
import pandas as pd
import torch

from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForTokenClassification,
    TrainingArguments,
    Trainer,
    DataCollatorForTokenClassification,
)

def load_examples(csv_path: Path):
    df = pd.read_csv(csv_path)
    df = df.rename(columns={c: c.strip() for c in df.columns})
    examples = []
    for _, row in df.iterrows():
       
        try:
            tokens = ast.literal_eval(row['Tokenised Filled Template'])
            labels_str = row.iloc[-1]  
            labels = ast.literal_eval(labels_str)
        except Exception as e:
            continue
        if isinstance(tokens, list) and isinstance(labels, list) and len(tokens) == len(labels):
            examples.append({'tokens': tokens, 'ner_tags': labels})
    return examples


def main():
    repo_root = Path(__file__).resolve().parent
    csv_path = repo_root / 'Dataset3' / 'Dataset.csv'
    if not csv_path.exists():
        print('Dataset not found at', csv_path)
        return

    examples = load_examples(csv_path)
    if not examples:
        print('No examples parsed from dataset.')
        return

    unique_labels = sorted({lab for ex in examples for lab in ex['ner_tags']})
    label2id = {l: i for i, l in enumerate(unique_labels)}
    id2label = {i: l for l, i in label2id.items()}

    ds = Dataset.from_list(examples)
    ds = ds.train_test_split(test_size=0.1)

    model_checkpoint = 'distilbert-base-uncased'
    tokenizer = AutoTokenizer.from_pretrained(model_checkpoint, use_fast=True)

    def tokenize_and_align_labels(examples_batch):
        tokenized_inputs = tokenizer(examples_batch['tokens'], is_split_into_words=True, truncation=True, max_length=128)
        all_labels = []
        for i, labels in enumerate(examples_batch['ner_tags']):
            word_ids = tokenized_inputs.word_ids(batch_index=i)
            previous_word_idx = None
            label_ids = []
            for word_idx in word_ids:
                if word_idx is None:
                    label_ids.append(-100)
                elif word_idx != previous_word_idx:
                    label_ids.append(label2id[labels[word_idx]])
                else:
                    # repeated token (subtoken) -> keep same label id
                    label_ids.append(label2id[labels[word_idx]])
                previous_word_idx = word_idx
            all_labels.append(label_ids)
        tokenized_inputs['labels'] = all_labels
        return tokenized_inputs

    tokenized = ds.map(tokenize_and_align_labels, batched=True, remove_columns=ds['train'].column_names)

    # Check for GPU availability
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    if device.type == 'cuda':
        print(f'GPU Name: {torch.cuda.get_device_name(0)}')
        print(f'GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB')

    model = AutoModelForTokenClassification.from_pretrained(model_checkpoint, num_labels=len(unique_labels), id2label=id2label, label2id=label2id)
    data_collator = DataCollatorForTokenClassification(tokenizer)

    # Use larger batch size for GPU training
    batch_size = 32 if device.type == 'cuda' else 8
    
    training_args = TrainingArguments(
        output_dir=str(repo_root / 'outputs' / 'ner-model'),
        eval_strategy='epoch',
        learning_rate=2e-5,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=64 if device.type == 'cuda' else 16,
        num_train_epochs=1,
        weight_decay=0.01,
        save_strategy='epoch',
        fp16=device.type == 'cuda', 
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized['train'],
        eval_dataset=tokenized['test'],
        data_collator=data_collator,
    )

    trainer.train()
    trainer.save_model(str(repo_root / 'outputs' / 'ner-model'))
    print('Training finished and model saved to outputs/ner-model')


if __name__ == '__main__':
    main()
