# Context-Aware NER & Sensitivity Masking

Fine-tune a DistilBERT transformer for Named Entity Recognition (NER) using BIO tagging to identify and mask sensitive information.

## Quick Start

### Installation

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Training (optional)

```powershell
python train.py
```

This trains 1 epoch on ~17.7k examples from the provided CSV dataset. Model saves to `outputs/ner-model`.

### Web Demo (Model mode)

```powershell
$env:MODEL_DIR = './outputs/ner-model'
python web_app/app.py
# Open http://localhost:5000 in your browser
```

The app uses the fine-tuned BERT model for masking sensitive information.

## Project Structure

- `notebooks/ner_masking.ipynb` — Preprocessing, tokenization, and training (Jupyter)
- `train.py` — End-to-end training script
- `web_app/app.py` — Flask API server
- `web_app/templates/index.html` — Interactive web interface
- `design_doc.md` — Architecture and approach documentation
- `Dataset3/Dataset.csv` — ~17.7k labeled examples in BIO format

## Architecture

1. **Data**: CSV with tokenized text and BIO-tagged labels
2. **Model**: Fine-tuned `distilbert-base-uncased` for token classification
3. **Tokenization**: Word-aligned with `DistilBertTokenizer`
4. **Training**: Hugging Face `Trainer` API with 1 epoch (batch size 8)
5. **Masking**: Aggregate entity spans and replace with `[MASK]` in output

## Example Usage

Input:

```
Technical support is available via UID: 8829-X or help.desk@corp.net. Visit our portal at https://user-profile.com/john_doe.
```

Expected output (with trained model):

```
Technical support is available via [MASK] or [MASK]. Visit our portal at [MASK].
```

## Evaluation Metrics

After training, `compute_metrics()` computes seqeval-based metrics:

- **Precision / Recall / F1**: Per-entity-type and overall
- **Confusion Matrix**: Available via `evaluate/plot_confusion.py` (after exporting predictions)

## Notes

- Training on GPU recommended (current: CPU training is slow)
- Uses `seqeval` for BIO sequence evaluation
- Model automatically handles subword tokens via word-id alignment
- Requires a trained model in the `outputs/ner-model` directory
