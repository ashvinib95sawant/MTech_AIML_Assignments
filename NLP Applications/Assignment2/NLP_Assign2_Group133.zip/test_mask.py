"""Quick script to test the trained model on example data."""
from transformers import pipeline
import sys

model_dir = 'outputs/ner-model'

try:
    nlp = pipeline('token-classification', model=model_dir, tokenizer=model_dir, aggregation_strategy='simple')
except Exception as e:
    print(f'Model load failed ({e}). Using demo mode.')
    nlp = None

def mask_text(text):
    if not nlp:
        return text.replace('UID:', '[MASK]UID:').replace('help.desk@corp.net', '[MASK]').replace('https://user-profile.com/john_doe', '[MASK]')
    
    preds = nlp(text)
    spans = []
    for p in preds:
        if p.get('entity_group') and p['entity_group'] != 'O' and p.get('score', 0) > 0.4:
            spans.append((p['start'], p['end']))
    spans = sorted(spans, key=lambda x: x[0])
    merged = []
    for s in spans:
        if not merged or s[0] > merged[-1][1]:
            merged.append(list(s))
        else:
            merged[-1][1] = max(merged[-1][1], s[1])
    masked = text
    for start, end in reversed(merged):
        masked = masked[:start] + '[MASK]' + masked[end:]
    return masked

if __name__ == '__main__':
    test_text = "Technical support is available via UID: 8829-X or help.desk@corp.net. Visit our portal at https://user-profile.com/john_doe."
    print("Input:", test_text)
    print("Output:", mask_text(test_text))
