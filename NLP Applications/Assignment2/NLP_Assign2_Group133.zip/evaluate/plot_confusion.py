import json
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt


with open('evaluate/preds_true.json') as f:
    data = json.load(f)

y_true = data['true']
y_pred = data['pred']
labels = sorted(list(set(y_true+y_pred)))
cm = confusion_matrix(y_true, y_pred, labels=labels)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
fig, ax = plt.subplots(figsize=(12,12))
disp.plot(ax=ax, xticks_rotation='vertical')
plt.tight_layout()
plt.show()
